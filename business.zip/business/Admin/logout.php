<?php

session_unset();
session_destroy();
header("location:login1.php");

?>